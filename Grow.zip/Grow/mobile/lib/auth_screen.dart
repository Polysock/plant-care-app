class LoginScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(validator: (v) => v!.isEmpty ? 'Required' : null),
            ElevatedButton(
              onPressed: () async {
                final token = await AuthService.login(email, password);
                await SecureStorage.saveToken(token);
              },
              child: Text('Login'),
            )
          ],
        ),
      ),
    );
  }
}